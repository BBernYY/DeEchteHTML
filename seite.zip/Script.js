init();
function go_to_the_scam_website(){
	window.open("scam.html","_self")
}
function change_element(id, txt){
	document.getElementById(id).innerHTML = txt;
}
function how_much_sussy(name, rng) {
	sus_level = name.length*10
	sus_random = Math.floor(Math.random()*100)
	if(rng){
	alert("You are "+sus_level.toString()+"% sussy.");
	}else{
	alert("You are "+sus_level.toString()+"% sussy.");
	}
}
function init(){
	userName = window.prompt("Please enter your name.", "")
	userSchool = window.prompt("Please enter your school.", "")
	userHouse = window.prompt("Please enter your address.", "")
	change_element("text", "Ik heb je gehacked. Jij, "+userName+" woont op "+userHouse+" en zit op "+userSchool)
}